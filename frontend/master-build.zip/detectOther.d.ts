declare const _default: never[];
export default _default;
